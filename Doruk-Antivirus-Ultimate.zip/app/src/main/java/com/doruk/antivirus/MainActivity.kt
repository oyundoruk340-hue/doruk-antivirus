package com.doruk.antivirus

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var results: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#0D1B2A"))
        }

        root.addView(TextView(this).apply {
            text = "DORUK-ANTİVİRÜS-ULTİMATE"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#4CC9F0"))
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            text = "Hazır"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Korumayı Başlat (arka plan)"
            setOnClickListener { startProtection() }
        })
        root.addView(Button(this).apply {
            text = "Şimdi Tara"
            setOnClickListener { runScan() }
        })

        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(results) })

        setContentView(root)
    }

    private fun startProtection() {
        ContextCompat.startForegroundService(this, Intent(this, ScanService::class.java))
        status.text = "Koruma aktif: yeni yüklenen uygulamalar anında taranır"
    }

    private fun runScan() {
        status.text = "Taranıyor..."
        results.removeAllViews()
        Thread {
            val list = Scanner.scanAll(packageManager)
            runOnUiThread {
                val bad = list.count { it.score >= 40 }
                status.text = "${list.size} uygulama tarandı, $bad şüpheli/tehlikeli"
                for (r in list) {
                    val color = when {
                        r.score >= 70 -> "#FF4D4D"
                        r.score >= 40 -> "#FFB703"
                        else -> "#52B788"
                    }
                    results.addView(TextView(this).apply {
                        text = "${r.level} (${r.score})  ${r.appName}\n" +
                            r.reasons.joinToString("\n") { "  • $it" }
                        setTextColor(Color.parseColor(color))
                        setPadding(0, 12, 0, 12)
                    })
                }
            }
        }.start()
    }
}
