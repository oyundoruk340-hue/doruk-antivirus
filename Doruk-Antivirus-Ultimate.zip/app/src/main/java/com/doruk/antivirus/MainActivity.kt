package com.doruk.antivirus

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var scanButton: Button

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun styledButton(label: String, bg: String, fg: String): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor(fg))
            background = rounded(Color.parseColor(bg), 16)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
            ).apply { topMargin = dp(12) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(16))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0D1B2A"), Color.parseColor("#1B263B"))
            )
        }

        // Logo
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_shield)
            layoutParams = LinearLayout.LayoutParams(dp(130), dp(130)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            }
        })

        root.addView(TextView(this).apply {
            text = "DORUK-ANTİVİRÜS"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "ULTİMATE"
            textSize = 14f
            letterSpacing = 0.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#4CC9F0"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(16))
        })

        // Durum kartı
        status = TextView(this).apply {
            text = "Cihazını taramaya hazır"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(18), dp(16), dp(18))
            background = rounded(Color.parseColor("#22334D"), 16)
        }
        root.addView(status)

        // Düğmeler
        val protectButton = styledButton("🛡  Korumayı Başlat", "#4CC9F0", "#0D1B2A")
        protectButton.setOnClickListener { startProtection() }
        root.addView(protectButton)

        scanButton = styledButton("🔍  Şimdi Tara", "#2D4263", "#FFFFFF")
        scanButton.setOnClickListener { runScan() }
        root.addView(scanButton)

        // Sonuç listesi
        results = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, dp(16))
        }
        root.addView(
            ScrollView(this).apply { addView(results) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
    }

    private fun startProtection() {
        ContextCompat.startForegroundService(this, Intent(this, ScanService::class.java))
        status.text = "✅ Koruma aktif\nYeni yüklenen uygulamalar anında taranır"
        status.setTextColor(Color.parseColor("#52B788"))
    }

    private fun runScan() {
        status.text = "Taranıyor..."
        status.setTextColor(Color.WHITE)
        scanButton.isEnabled = false
        results.removeAllViews()
        Thread {
            val list = Scanner.scanAll(packageManager)
            runOnUiThread {
                val bad = list.count { it.score >= 40 }
                status.text = if (bad == 0) {
                    "✅ ${list.size} uygulama tarandı\nTehdit bulunmadı"
                } else {
                    "⚠️ ${list.size} uygulama tarandı\n$bad şüpheli/tehlikeli uygulama"
                }
                status.setTextColor(
                    Color.parseColor(if (bad == 0) "#52B788" else "#FFB703")
                )
                scanButton.isEnabled = true

                for (r in list) {
                    val color = when {
                        r.score >= 70 -> "#FF4D4D"
                        r.score >= 40 -> "#FFB703"
                        else -> "#52B788"
                    }
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(16), dp(12), dp(16), dp(12))
                        background = rounded(Color.parseColor("#22334D"), 14)
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = dp(10) }
                    }
                    card.addView(TextView(this).apply {
                        text = "${r.appName}  •  ${r.level} (${r.score})"
                        textSize = 15f
                        setTypeface(null, Typeface.BOLD)
                        setTextColor(Color.parseColor(color))
                    })
                    if (r.reasons.isNotEmpty()) {
                        card.addView(TextView(this).apply {
                            text = r.reasons.joinToString("\n") { "• $it" }
                            textSize = 13f
                            setTextColor(Color.parseColor("#B0BEC5"))
                            setPadding(0, dp(6), 0, 0)
                        })
                    }
                    results.addView(card)
                }
            }
        }.start()
    }
}
