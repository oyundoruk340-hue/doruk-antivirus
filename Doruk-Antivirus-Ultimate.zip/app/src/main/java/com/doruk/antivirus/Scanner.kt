package com.doruk.antivirus

import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

data class ScanResult(
    val packageName: String,
    val appName: String,
    val score: Int,
    val reasons: List<String>
) {
    val level: String
        get() = when {
            score >= 70 -> "TEHLİKELİ"
            score >= 40 -> "ŞÜPHELİ"
            else -> "TEMİZ"
        }
}

/**
 * Heuristic (davranış/izin tabanlı) tarayıcı.
 * Gerçek zamanlı imza veritabanı içermez; kural + kara liste mantığıyla çalışır.
 */
object Scanner {

    // Örnek kara liste. Gerçek kullanımda sunucudan güncellenmelidir.
    private val blockedPackages = setOf(
        "com.example.fakeantivirus",
        "com.example.spyware"
    )

    private val permissionWeights = mapOf(
        "android.permission.SEND_SMS" to 15,
        "android.permission.READ_SMS" to 15,
        "android.permission.RECEIVE_SMS" to 10,
        "android.permission.SYSTEM_ALERT_WINDOW" to 15,
        "android.permission.REQUEST_INSTALL_PACKAGES" to 15,
        "android.permission.BIND_DEVICE_ADMIN" to 20,
        "android.permission.READ_CALL_LOG" to 10,
        "android.permission.RECORD_AUDIO" to 8,
        "android.permission.READ_CONTACTS" to 8,
        "android.permission.ACCESS_FINE_LOCATION" to 5,
        "android.permission.QUERY_ALL_PACKAGES" to 5,
        "android.permission.BIND_ACCESSIBILITY_SERVICE" to 25
    )

    private val trustedInstallers = setOf(
        "com.android.vending",
        "com.huawei.appmarket",
        "com.sec.android.app.samsungapps",
        "com.amazon.venezia"
    )

    fun scanPackage(pm: PackageManager, pkg: String): ScanResult? {
        val info: PackageInfo = try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(
                    pkg,
                    PackageManager.PackageInfoFlags.of(
                        (PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES).toLong()
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(
                    pkg,
                    PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES
                )
            }
        } catch (e: Exception) {
            return null
        }
        val app = info.applicationInfo ?: return null
        if (app.flags and ApplicationInfo.FLAG_SYSTEM != 0) return null

        var score = 0
        val reasons = mutableListOf<String>()

        if (pkg in blockedPackages) {
            score += 100
            reasons += "Kara listedeki uygulama"
        }

        val perms = info.requestedPermissions?.toSet() ?: emptySet()
        for ((perm, weight) in permissionWeights) {
            if (perm in perms) {
                score += weight
                reasons += "Riskli izin: ${perm.substringAfterLast('.')}"
            }
        }

        val hasSms = "android.permission.SEND_SMS" in perms || "android.permission.READ_SMS" in perms
        val hasOverlay = "android.permission.SYSTEM_ALERT_WINDOW" in perms
        if (hasSms && hasOverlay) {
            score += 20
            reasons += "SMS + ekran üstü çizim kombinasyonu (bankacılık zararlısı davranışı)"
        }

        val installer = try {
            if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
            else @Suppress("DEPRECATION") pm.getInstallerPackageName(pkg)
        } catch (e: Exception) {
            null
        }
        if (installer == null || installer !in trustedInstallers) {
            score += 10
            reasons += "Güvenilir mağaza dışından yüklenmiş"
        }

        if (app.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) {
            score += 10
            reasons += "Debug modunda derlenmiş"
        }

        val label = pm.getApplicationLabel(app).toString()
        return ScanResult(pkg, label, score.coerceAtMost(100), reasons)
    }

    fun scanAll(pm: PackageManager): List<ScanResult> {
        val packages = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(0)
        }
        return packages
            .mapNotNull { scanPackage(pm, it.packageName) }
            .sortedByDescending { it.score }
    }
}
